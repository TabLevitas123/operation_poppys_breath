# Repository notes

This private repository is the durable working copy for the Opioid Causal Systems Atlas (OCSA).

## Canonical data

- `atlas.db` is the canonical local evidence store.
- `exports/` contains generated portable views.
- `snapshots/` contains versioned release archives.
- Scientific claims are not yet populated in version 0.1.0.

## Integrity controls currently active

- SQLite foreign-key enforcement and application validation
- Automated unit tests
- GitHub Actions validation on pushes and pull requests
- SHA-256 release manifest
- Versioned snapshots

Future hardening should add append-only claim versions, source-file hashes, exact evidence spans, citation-resolution checks, review gates, and tamper-evident change logs before scientific ingestion begins.
